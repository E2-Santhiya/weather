import 'package:flutter/material.dart';
import 'package:weather/model/weather_model.dart';
import 'package:weather/services/weather_api_client.dart';
import 'package:weather/today_weather.dart';
import 'package:weather/views/additional_information.dart';
import 'package:weather/views/current_weather.dart';
import 'package:weather/detailPage.dart';
import 'package:intl/intl.dart';
import 'package:jiffy/jiffy.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return const MaterialApp(
      debugShowCheckedModeBanner: false,
      home: HomePage(),
    );
  }
}

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  WeatherApiClient client = WeatherApiClient();
  Weather? data;

  @override
  void initState() {
    // TODO: implement initState
    super.initState();
    client.getCurrentWeather("Chennai");
  }

  Future<void> getData() async {
    data = await client.getCurrentWeather("Chennai");
  }

  /// Build method

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        backgroundColor: const Color(0xFFf9f9f9),
        appBar: AppBar(
            backgroundColor: const Color(0xFFf9f9f9),
            elevation: 0.0,
            title: const Text("Weather app",
                style: TextStyle(color: Colors.black)),
            centerTitle: true,
            leading: IconButton(
              onPressed: () {},
              icon: const Icon(Icons.menu),
              color: Colors.black,
            )),
        body: FutureBuilder(
          future: getData(),
          builder: (context, snapshot) {
            if (snapshot.connectionState == ConnectionState.done) {
              return SingleChildScrollView(
                  child: Column(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  currentWeather(
                      " https://openweathermap.org/img/w/04d.png,",
                      "${data!.temp}\u00B0C",
                      "${data!.city}",
                      Jiffy().yMMMd,
                      DateFormat.jm().format(DateTime.now()),
                      "${data!.description}",
                      "${data!.lat}",
                      "${data!.lon}",
                      "${data!.temp_min}\u00B0C",
                      "${data!.temp_max}\u00B0C"),
                  const SizedBox(
                    height: 10.0,
                  ),
                  const Padding(padding: EdgeInsets.only(right: 10.0)),
                  const Text(
                    "Additional Information",
                    style: TextStyle(fontSize: 24.0, color: Colors.blueAccent),
                  ),
                  const Divider(),
                  const SizedBox(
                    height: 10.0,
                  ),
                  additionalInformation("${data!.wind}", "${data!.humidity}",
                      "${data!.pressure}", "${data!.feels_like}"),
                  const Padding(padding: EdgeInsets.only(right: 60.0)),
                  const SizedBox(
                    height: 20.0,
                  ),
                  Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    crossAxisAlignment: CrossAxisAlignment.center,
                    children: [
                      const Padding(padding: EdgeInsets.only(right: 10.0)),
                      Row(
                        // mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        crossAxisAlignment: CrossAxisAlignment.center,
                        children: [
                          const Padding(padding: EdgeInsets.only(left: 20.0)),
                          const Text(
                            "Today",
                            style: TextStyle(
                                fontSize: 20,
                                fontWeight: FontWeight.bold,
                                color: Colors.blue),
                          ),
                          SingleChildScrollView(
                            scrollDirection: Axis.vertical,
                            child: GestureDetector(
                              onTap: () {
                                Navigator.push(context, MaterialPageRoute(
                                    builder: (BuildContext context) {
                                  return DetailPage();
                                }));
                              },
                              child: Row(
                                children: const [
                                  Padding(
                                      padding: EdgeInsets.only(left: 210.0)),
                                  Text(
                                    "More days",
                                    style: TextStyle(
                                        fontSize: 18, color: Colors.blue),
                                  ),
                                  Icon(
                                    Icons.arrow_forward_ios_outlined,
                                    color: Colors.blue,
                                    size: 15,
                                  )
                                ],
                              ),
                            ),
                          )
                        ],
                      ),
                    ],
                  ),
                  const SizedBox(height: 18.0),
                  SingleChildScrollView(
                    scrollDirection: Axis.horizontal,
                    child: Row(
                      children: <Widget>[
                        GestureDetector(
                          onTap: () {
                            Navigator.push(context, MaterialPageRoute(
                                builder: (BuildContext context) {
                              return const TodayWeather();
                            }));
                          },
                          child: Row(
                            children: [
                              const Padding(
                                  padding: EdgeInsets.only(left: 5.0)),
                              const Text(
                                "Click here for ",
                                style:
                                    TextStyle(fontSize: 18, color: Colors.blue),
                              ),
                              const Text(
                                "today weather",
                                style:
                                    TextStyle(fontSize: 18, color: Colors.blue),
                              ),
                              Image.network(
                                  'https://openweathermap.org/img/w/04d.png',
                                  height: 120,
                                  width: 120,
                                  fit: BoxFit.fill),
                              const Icon(
                                Icons.arrow_forward_ios_outlined,
                                color: Colors.blue,
                                size: 18,
                              )
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ));
            } else if (snapshot.connectionState == ConnectionState.waiting) {
              return const Center(
                child: CircularProgressIndicator(),
              );
            }
            return Container();
          },
        ));
  }
}
