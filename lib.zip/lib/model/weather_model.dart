/// Model for weather forecast

class Weather {
  double? temp;
  double? wind;
  int? humidity;
  double? feels_like;
  int? pressure;
  String? description;
  double? temp_min;
  double? temp_max;
  String? city;
  double? lat;
  double? lon;
  String? dates;
  Weather({
    this.temp,
    this.wind,
    this.humidity,
    this.feels_like,
    this.pressure,
    this.description,
    this.city,
    this.lat,
    this.lon,
    this.temp_min,
    this.temp_max,
    this.dates,
  });

  /// Json for api

  Weather.fromJson(Map<String, dynamic> json) {
    temp = json["list"][0]["main"]["temp"];
    wind = json["list"][0]["wind"]["speed"];
    pressure = json["list"][0]["main"]["pressure"];
    humidity = json["list"][0]["main"]["humidity"];
    feels_like = json["list"][0]["main"]["feels_like"];
    description = json["list"][0]["weather"][0]["description"];
    city = json["city"]["name"];
    lat = json["city"]["coord"]["lat"];
    lon = json["city"]["coord"]["lon"];
    temp_min = json["list"][0]["main"]["temp_min"];
    temp_max = json["list"][0]["main"]["temp_max"];
    dates = json["list"][0]["dt_txt"];
  }
}
